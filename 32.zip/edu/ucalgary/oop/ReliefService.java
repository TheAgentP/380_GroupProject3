package edu.ucalgary.oop;
import java.util.regex.*;
public class ReliefService {
    private Inquirer inquirer;
    private DisasterVictim missingPerson;
    private String dateOfInquiry, infoProvided;
    private Location lastKnownLocation;

    private static final String REGEX = "^\\d{4}-\\d{2}-\\d{2}$";
    private static final Pattern PATTERN = Pattern.compile(REGEX);

    // NOTE: ReliefService doesn't have a constructor in the UML Diagram! Mistake(?)

    // Updated Constructor

    ReliefService(Inquirer inquirer, DisasterVictim missingPerson, String validDate, String expectedInfoProvided, Location lastKnownLocation){
        this.inquirer = inquirer;
        this.missingPerson = missingPerson;
        this.dateOfInquiry = validDate;
        this.infoProvided = expectedInfoProvided;
        this.lastKnownLocation = lastKnownLocation;
    }

    public Inquirer getInquirer() {return inquirer;}

    public void setInquirer(Inquirer inquirer) {this.inquirer = inquirer;}

    public DisasterVictim getMissingPerson() {return missingPerson;}

    public void setMissingPerson(DisasterVictim missingPerson) {this.missingPerson = missingPerson;}

    public String getDateOfInquiry() {return dateOfInquiry;}

    public void setDateOfInquiry(String dateOfInquiry) throws IllegalArgumentException{
        Matcher match = PATTERN.matcher(dateOfInquiry);
        boolean matchFound = match.find();
        if(matchFound){
            this.dateOfInquiry = dateOfInquiry;
        }
        else{
            throw new IllegalArgumentException("IllegalArgumentException: not a valid input: " + dateOfInquiry);
        }
    }

    public String getInfoProvided() {return infoProvided;}

    public void setInfoProvided(String infoProvided) {this.infoProvided = infoProvided;}

    public Location getLastKnownLocation() {return lastKnownLocation;}

    public void setLastKnownLocation(Location lastKnownLocation) {this.lastKnownLocation = lastKnownLocation;}

    public void printLogDetails() {
        System.out.println("Relief Service Inquiry Details:");
        System.out.println("Date of Inquiry: " + dateOfInquiry);
        System.out.println("Inquirer: " + (inquirer != null ? inquirer.getFirstName() + " " + inquirer.getLastName()  : "Not specified"));
        System.out.println("Missing Person: " + (missingPerson != null ? missingPerson.getFirstName() + " " + missingPerson.getLastName() : "Not specified"));
        System.out.println("Information Provided: " + infoProvided);
        System.out.println("Last Known Location: " + (lastKnownLocation != null ? lastKnownLocation.getName() : "Not specified"));
    }

    // Method to get log details as a string
    public String getLogDetails() {
        return "Inquirer: " + inquirer.getFirstName() + ", Missing Person: " + missingPerson.getFirstName() + ", Date of Inquiry: " + dateOfInquiry + ", Info Provided: " + infoProvided + ", Last Known Location: " + lastKnownLocation.getName();
    }
}