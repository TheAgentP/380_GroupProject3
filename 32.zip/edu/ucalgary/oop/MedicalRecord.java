package edu.ucalgary.oop;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MedicalRecord {
    private Location location;
    private String treatmentDetails, dateOfTreatment;
    private static final String REGEX = "^\\d{4}-\\d{2}-\\d{2}$";
    private static final Pattern PATTERN = Pattern.compile(REGEX);

    MedicalRecord(Location location, String treatmentDetails, String dateOfTreatment) throws IllegalArgumentException{
        Matcher match = PATTERN.matcher(dateOfTreatment);
        boolean matchFound = match.find();
        if(matchFound){
            this.dateOfTreatment = dateOfTreatment;
            this.location = location;
            this.treatmentDetails = treatmentDetails;
        }
        else{
            throw new IllegalArgumentException("IllegalArgumentException: not a valid input: " + dateOfTreatment);
        }

    }
    // getVictim
    // setVictim
    public Location getLocation(){return location;}

    public void setLocation(Location location){this.location = location;}

    public String getDateOfTreatment() {return dateOfTreatment;}

    public String getTreatmentDetails() {return treatmentDetails;}

    public void setDateOfTreatment(String dateOfTreatment) throws IllegalArgumentException{
        Matcher match = PATTERN.matcher(dateOfTreatment);
        boolean matchFound = match.find();
        if(matchFound){
            this.dateOfTreatment = dateOfTreatment;
        }
        else{
            throw new IllegalArgumentException("IllegalArgumentException: not a valid input: " + dateOfTreatment);
        }
    }

    public void setTreatmentDetails(String treatmentDetails) {this.treatmentDetails = treatmentDetails;}

}
